﻿
function isNumberOnlyKey(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if ((charCode >= 48 && charCode <= 57) || ((charCode <= 110 && charCode >= 96))) {
        return true;    
    }
    else
        return false;
    
}

function isAlphaNumberOnlyKey(e) {
    var key = e.which || e.keyCode;
    if (e.shiftKey && key >= 48 && key <= 57) {
        return false;
    }
    else {
        if (key >= 186 && key <= 187 || key >= 191 && key <= 222 || key == 32) {
            return false;
        }
        else {
            return true;
        }
    }
}

function isNumerDecimalOnly(evt, element) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 &&  !((charCode >= 48 && charCode <= 57) || ((charCode <= 110 && charCode >= 96))) && !(charCode == 46 || charCode == 8))
        return false;
    else {
        var len = $(element).val().length;
        var index = $(element).val().indexOf('.');
        if (index > 0 && charCode == 46) {
            return false;
        }
        if (index > 0) {
            var CharAfterdot = (len + 1) - index;
            if (CharAfterdot > 3) {
                return false;
            }
        }

    }
    return true;
}

function isNumberCommaDot(evt) {
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;

    if (key === 9) { //TAB was pressed
        return;
    }

    key = String.fromCharCode(key);
    if (key.length == 0) return;
    var regex = /^[0-9,\9\b]*\.?[0-9]*$/;
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (!regex.test(key) && !((charCode >= 48 && charCode <= 57) || ((charCode <= 110 && charCode >= 96)))) {
        theEvent.returnValue = false;
        if (theEvent.preventDefault) theEvent.preventDefault();
    }
}

function isNumerDecimalFourOnly(evt, element) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 &&  !((charCode >= 48 && charCode <= 57) || ((charCode <= 110 && charCode >= 96))) && !(charCode == 46 || charCode == 8))
        return false;
    else {
        var len = $(element).val().length;
        var index = $(element).val().indexOf('.');
        if (index > 0 && charCode == 46) {
            return false;
        }
        if (index > 0) {
            var CharAfterdot = (len + -1) - index;
            if (CharAfterdot > 3) {
                return false;
            }
        }

    }
    return true;
}


//function isAlphaNumberOnlyKey(e) {
//    var k = evt.keyCode || evt.which;
//    var ok = k >= 65 && k <= 90 || // A-Z
//        k >= 96 && k <= 105 || // a-z
//        k >= 35 && k <= 40 || // arrows
//        k == 9 || //tab
//        k == 46 || //del
//        k == 8 || // backspaces
//        (!evt.shiftKey && k >= 48 && k <= 57); // only 0-9 (ignore SHIFT options)

//    if (!ok || (evt.ctrlKey && evt.altKey)) {
//        evt.preventDefault();
//    }
//}

function isAlphaNumberOnlyKey1(evt) {
    var keyCode = e.keyCode || e.which;

    //Regex for Valid Characters i.e. Alphabets and Numbers.
    var regex = /^[A-Za-z0-9]+$/;

    var isValid = regex.test(String.fromCharCode(keyCode));
    if (!isValid) {
        SwalErrMsg("Only Alphabets and Numbers allowed !!");
        return false;
    }
    else {
        return true;
    }
}

function emailvalidate(email) {
    var aemail = email;
    var expr = /^([\w-\.]+)@@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (!expr.test(aemail)) {
       SwalErrMsg("Invalid email address. !!");
        return false;        
    }
    else {
        return true;
    }
}

function dfdemailvalidate(email) {        
    var expr = /^([\w-\.]+)@@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;    
    if (!expr.test(email)) {
        SwalErrMsg("Invalid email address.");
    }    
}

function add_autocomplete($obj, controls) {
    var oldFn = $.ui.autocomplete.prototype._renderItem;
    $.ui.autocomplete.prototype._renderItem = function (ul, item) {
        var re = new RegExp(this.term, "i");
        var t = item.label.replace(re, "<strong style='font-weight:bold;background:#C7DFFE;border-radius:2px;border:1px solid #98B8E1'>" + this.term + "</strong>");
        return $("<li></li>")
            .data("item.autocomplete", item)
            .append("<a>" + t + "</a>")
            .appendTo(ul);
    };
    $obj.autocomplete({
        source: function (request, response) {
            $.ajax({
                url: $obj.data("autocomplete-url"),
                type: "POST",
                dataType: "json",
                max: 10,
                scrollable: true,
                data: {
                    term: request.term
                },
                success: function (data) {

                    response($.map(data, function (item) {
                        count = 0;
                        item_str = "";
                        var jsonArg = new Object();
                        count = 0;
                        $.each(item, function (i, data) {
                            switch (count) {
                                case 0:
                                    jsonArg.label = data;// + " (" + item['WRDCODE'] + ")";
                                    jsonArg.value = data;
                                    break;
                                case 1:
                                    jsonArg.id = data;
                                    break;
                                case 2:
                                    jsonArg.desc = data;
                                    break;
                                case 3:
                                    jsonArg.xparam1 = data;
                                    break;
                                case 4:
                                    jsonArg.xparam2 = data;
                                    break;
                                case 5:
                                    jsonArg.xparam3 = data;
                                    break
                                case 6:
                                    jsonArg.xparam4 = data;
                                    break


                            }
                            count++
                        });
                        return jsonArg
                    }))
                }
            })
        },
        search: function () {
            var term = extractLast(this.value);
            if (term.length < 2) {
                return false
            }
        },
        select: function (event, ui) {
            $(this).val(ui.item.label);
            count = 0;
            $.each(controls.split(','), function (index, value) {
                switch (count) {

                    case 1:
                        $("#" + value).val(ui.item.id);
                        break;
                    case 2:
                        $("#" + value).val(ui.item.desc);
                        break;
                    case 3:
                        $("#" + value).val(ui.item.xparam1);
                        break;
                    case 4:
                        $("#" + value).val(ui.item.xparam2);
                        break;
                    case 5:
                        $("#" + value).val(ui.item.xparam3);
                        break
                    case 6:
                        $("#" + value).val(ui.item.xparam4);
                        break



                }
                count++
            });



            return false
        },
        change: function (event, ui) {
            //debugger;
            var opt = $(this).val();

            var crntval = event.currentTarget.value;            
            $.ajax({
                type: 'POST',
                contentType: 'application/json; charset=utf-8',
                url: $obj.data("autocomplete-url"),
                data: "{'term':'" + crntval + "'}",
                dataType: 'json',
                success: function (data) {
                    //debugger;
                    if (data.length == 0) {
                        //$(event.currentTarget).val('');
                        alert('Select Items from the list.')                       
                        //SwalErrMsg('Select Items from the list.');
                    }                   
                },
                error: function (data) {
                    $(event.currentTarget).val('');
                    console.log('Error retrieving options.');
                }
            });
        },
        messages: {
            noResults: "",
            results: ""
        }
    })
}

function isAlphaNumeric(chkval) {
    var TCode = chkval;
    var Exp = /((^[0-9]+[a-z]+)|(^[a-z]+[0-9]+))+[0-9a-z]+$/i;
    if (!TCode.match(Exp))
        return false;
    else
        return true;
}

function isGstNumber(chkgst) {
    var gst_value = chkgst.toUpperCase();
    var reg = /^([0-9]{2}[a-zA-Z]{4}([a-zA-Z]{1}|[0-9]{1})[0-9]{4}[a-zA-Z]{1}([a-zA-Z]|[0-9]){3}){0,15}$/;
    if (gst_value.match(reg)) {
        return true;
    } else {
        return false;
    }
}


function GetFormattedDate(obj) {
    var MyDate_String_Value = obj;
    var value1 = new Date
        (
            parseInt(MyDate_String_Value.replace(/(^.*\()|([+-].*$)/g, ''))
        );
    var dat = value1.getDate() +
        "-" +
        eval(value1.getMonth() + 1) +
        "-" +
        value1.getFullYear();
    return dat;
}
function GetFormattedDateTime(obj) {
    var MyDate_String_Value = obj;
    var value1 = new Date
        (
            parseInt(MyDate_String_Value.replace(/(^.*\()|([+-].*$)/g, ''))
        );
    var dat = value1.getDate() +
        "-" +
        eval(value1.getMonth() + 1) +
        "-" +
        value1.getFullYear() + " " + value1.getHours() + ":" + value1.getMinutes();
    return dat;
}
function SwalErrMsg(msg) {
    //Swal.fire(
    //    'Error!',
    //    '<strong>'+ msg+'</strong>',
    //    'error'
    //);
    alert(msg);

}

function SwalSucMsg(msg) {
    //Swal.fire(
    //    'Success!',
    //    '<strong>' + msg + '</strong>',
    //    'success'
    //);
    alert(msg);

}
function SwalInfMsg(msg) {
    //Swal.fire(
    //    'Information!',
    //    '<strong>' + msg + '</strong>',
    //    'info'
    //);
    alert(msg);

}

function SwalAlert(msg) {
    //Swal.fire(
    //    'Alert!',
    //    '<strong>' + msg + '</strong>',
    //    'info'
    //);
    alert(msg);

}
