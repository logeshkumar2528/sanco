<?php

header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=qrcode.jpg");
    readfile('qrcode.jpg');
    die;


?>