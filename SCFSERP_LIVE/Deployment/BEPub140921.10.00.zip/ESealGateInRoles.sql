
select *from AspNetRoles where Name Like '%ESealGateIn%'

Update AspNetRoles set RMenuType='Gate In',RControllerName='ESealGateIn',RMenuGroupId=4,RMenuGroupOrder=1,RMenuIndex='Index' where id='2604684c-ead0-46a4-ad67-24c50b001387'

Update AspNetRoles set RMenuType='Gate In',RControllerName='ESealGateIn',RMenuGroupId=4,RMenuGroupOrder=1,RMenuIndex='Index' where id='2e9ba0bb-eab2-4031-8cff-184f0424e6ac'

Update AspNetRoles set RMenuType='Gate In',RControllerName='ESealGateIn',RMenuGroupId=4,RMenuGroupOrder=1,RMenuIndex='Index' where id='5248ccdb-14c7-4e4b-8966-32987c50aa35'

Update AspNetRoles set RMenuType='Gate In',RControllerName='ESealGateIn',RMenuGroupId=4,RMenuGroupOrder=1,RMenuIndex='Index' where id='91849771-a79e-4422-a2cb-899cc3713fb4'

Update AspNetRoles set RMenuType='Gate In',RControllerName='ESealGateIn',RMenuGroupId=4,RMenuGroupOrder=1,RMenuIndex='Index' where id='ab4c1268-ea0e-41b0-add6-c49173ce7dfa'