select * from SOFT_TABLE_DELETE_DETAIL
where optnstr = 'CARTINGORDER'

select * from SOFT_TABLE_DELETE_DETAIL
where optnstr = 'exportshippingbillmaster'

select * from SOFT_TABLE_DELETE_DETAIL
where optnstr = 'SHIPPINGADMISSION'

select * from SOFT_TABLE_DELETE_DETAIL
where optnstr = 'EXPORTSHIPPINGBILLDETAIL'


update SOFT_TABLE_DELETE_DETAIL
set optnstr = 'EXPORTSHIPPINGBILLDETAIL'
where optnstr = 'SHIPPINGADMISSION'

update SOFT_TABLE_DELETE_DETAIL
set DCONDTNSTR = 'STFTID=0 AND ESBMID='
where optnstr = 'EXPORTSHIPPINGBILLDETAIL'
and DCONDTNSTR ='STFTID=0 AND EEESBMID='


update SOFT_TABLE_DELETE_DETAIL
set DCONDTNSTR = 'STFTID=1 AND ESBMID='
where optnstr = 'EXPORTSHIPPINGBILLDETAIL'
and DCONDTNSTR ='STFTID=1 AND EEESBMID='



update SOFT_TABLE_DELETE_DETAIL
set DCONDTNSTR = 'STFTID=2 AND ESBMID='
where optnstr = 'EXPORTSHIPPINGBILLDETAIL'
and DCONDTNSTR ='STFTID=2 AND EEESBMID='

-- select max (tabdid) from SOFT_TABLE_DELETE_DETAIL where TABNAME = 'EXPORTSHIPPINGBILLDETAIL'
delete  SOFT_TABLE_DELETE_DETAIL where tabdid = 51
if not exists (select '*' from SOFT_TABLE_DELETE_DETAIL where tabdid = 51)
begin	
	
	insert into SOFT_TABLE_DELETE_DETAIL
	select 51, 'SHIPPINGBILLDETAIL', 'EXPORTSHIPPINGBILLDETAIL', 'ESBMID', 'ESBMID=', 'Selected Record Referred Shipping Admission Detail..........................!'
end
delete  SOFT_TABLE_DELETE_DETAIL where tabdid = 52
if not exists (select '*' from SOFT_TABLE_DELETE_DETAIL where tabdid = 52)
begin	
	insert into SOFT_TABLE_DELETE_DETAIL
	select 52, 'EXPORTSHIPPINGBILLMASTER', 'EXPORTSHIPPINGBILLDETAIL', 'ESBMID', 'ESBMID=', 'Selected Record Referred Shipping Admission Detail..........................!'

--	TABDID	OPTNSTR	TABNAME	PFLDNAME	DCONDTNSTR	DISPDESC
--34	EXPORTSHIPPINGBILLMASTER	SHIPPINGBILLDETAIL	SBDID	ESBMID=	Selected Record Referred Carting Order Detail..........................!
delete SOFT_TABLE_DELETE_DETAIL where tabdid = 34
end

delete  SOFT_TABLE_DELETE_DETAIL where tabdid = 53
if not exists (select '*' from SOFT_TABLE_DELETE_DETAIL where tabdid = 53)
begin	
	
	insert into SOFT_TABLE_DELETE_DETAIL
	select 53, 'VEHICLETICKETDETAIL', 'GATEINDETAIL INNER JOIN VEHICLETICKETDETAIL ON VEHICLETICKETDETAIL.GIDID=GATEINDETAIL.GIDID', 'VEHICLETICKETDETAIL.GIDID', 'GATEINDETAIL.GIDID=', 'Selected Record Exists In Vehicle ticket Detail ...........!'
end