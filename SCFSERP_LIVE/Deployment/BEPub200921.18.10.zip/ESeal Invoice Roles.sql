select * from aspnetroles where name like 'esealinv%'

update AspNetRoles
set RMenuType = 'ESeal Invoice', RControllerName = 'ESealInvoice', RMenuGroupId = 23, RMenuGroupOrder = 4, RMenuIndex = 'Index'
where name like 'ESealInvoice%'	
and RMenuIndex is null
