select *from AspNetRoles where NAme Like '%ESealVT%'

update AspNetRoles SET RMenuType='Vehicle Ticket (ES)',RControllerName='ESealVehicleTicket',RMenuGroupId=4,RMenuGroupOrder=2,RMenuIndex='Index' where NAme Like '%ESealVT%'