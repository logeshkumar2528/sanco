select * from AspNetRoles where Name like 'opensheet%'
--select * from AspNetRoles where Name like 'importlorry%'
update AspNetRoles 
set RMenuGroupId		=	11 , 
	RMenuGroupOrder		=	12, 
	Discriminator		=	'ApplicationRole', 
	RMenuType			=	'Manual OpenSheet', 
	RControllerName		=	'Manual OpenSheet'
where name like 'manualopensheet%'