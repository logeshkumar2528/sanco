select *from AspNetRoles WHERE Name LIke '%ESealGO%' 

update AspNetRoles SET RMenuType='Gate Out (ES)',RControllerName='ESealGateOut',RMenuGroupId=4,RMenuGroupOrder=3,RMenuIndex='Index' where NAme Like '%ESealGO%'