USE [SCFS_ERP]
GO

/****** Object:  View [dbo].[Z_IMPORT_EINVOICE_DETAILS]    Script Date: 11-10-2021 16:42:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[Z_IMPORT_EINVOICE_DETAILS]
AS
SELECT        dbo.COMPANYMASTER.COMPNAME, dbo.TRANSACTIONMASTER.COMPYID, dbo.TRANSACTIONMASTER.TRANMID, dbo.TRANSACTIONMASTER.SDPTID, dbo.TRANSACTIONMASTER.REGSTRID, 
                         dbo.TRANSACTIONMASTER.TRANBTYPE, dbo.TRANSACTIONMASTER.TRANDATE, RIGHT(dbo.TRANSACTIONMASTER.TRANTIME, 8) AS TRANTIME, dbo.TRANSACTIONMASTER.TRANNO, dbo.TRANSACTIONMASTER.TRANDNO, 
                         dbo.TRANSACTIONMASTER.TRANREFNAME, dbo.TRANSACTIONMASTER.TRANMODE, dbo.TRANSACTIONMASTER.TRANMODEDETL, dbo.TRANSACTIONMASTER.TRANREFNO, dbo.TRANSACTIONMASTER.TRANREFDATE, 
                         dbo.TRANSACTIONMASTER.TRANREFBNAME, dbo.TRANSACTIONMASTER.TRANREFAMT, dbo.TRANSACTIONMASTER.TRANGAMT, dbo.TRANSACTIONMASTER.TRANSAMT, dbo.TRANSACTIONMASTER.TRANHAMT, 
                         dbo.TRANSACTIONMASTER.TRANEAMT, dbo.TRANSACTIONMASTER.TRANFAMT, dbo.TRANSACTIONMASTER.TRANAAMT, dbo.TRANSACTIONMASTER.TRANNAMT, dbo.TRANSACTIONMASTER.TRANAMTWRDS, 
                         dbo.TRANSACTIONMASTER.TRANRMKS, MAX(dbo.GATEINDETAIL.IMPRTNAME) AS IMPRTNAME, MAX(dbo.GATEINDETAIL.STMRNAME) AS STMRNAME, SUM(dbo.TRANSACTIONDETAIL.TRANDQTY) AS TRANDQTY, 
                         SUM(dbo.TRANSACTIONDETAIL.TRANDGAMT) AS TRANDGAMT, SUM(dbo.TRANSACTIONDETAIL.TRANDSAMT) AS TRANDSAMT, SUM(dbo.TRANSACTIONDETAIL.TRANDHAMT) AS TRANDHAMT, 
                         SUM(dbo.TRANSACTIONDETAIL.TRANDEAMT) AS TRANDEAMT, SUM(dbo.TRANSACTIONDETAIL.TRANDFAMT) AS TRANDFAMT, SUM(dbo.TRANSACTIONDETAIL.TRANDAAMT) AS TRANDAAMT, 
                         SUM(dbo.TRANSACTIONDETAIL.TRANDNAMT) AS TRANDNAMT, dbo.TRANSACTIONMASTER.LMUSRID, dbo.TRANSACTIONMASTER.CUSRID, dbo.TRANSACTIONMASTER.LMUSRID AS USRNAME, 
                         dbo.TRANSACTIONMASTER.DISPSTATUS, dbo.OPENSHEETMASTER.OSMLNAME, dbo.COMPANYMASTER.COMPPDESC1, dbo.COMPANYMASTER.COMPPDESC2, dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01.COL1, 
                         dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01.COL2, dbo.TRANSACTIONMASTER.TRANNARTN, MAX(ISNULL(dbo.TRANSACTIONMASTER.TRANHBLNO, dbo.BILLENTRYMASTER.BLNO)) AS TRANHBLNO, 
                         dbo.TRANSACTIONMASTER.TRANPONO, dbo.GATEINDETAIL.CHANAME, dbo.GATEINDETAIL.CLNTNAME, dbo.GATEINDETAIL.SHPRNAME, dbo.GATEINDETAIL.GPPLCNAME, dbo.TRANSACTIONDETAIL.TRANDAHAMT, 
                         dbo.TRANSACTIONMASTER.TRANAHAMT, dbo.COMPANYMASTER.COMPGSTNO, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_HSNCODE, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_HSNCODE, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_CGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_SGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_IGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_CGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_SGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_IGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_TAXABLE_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_TAXABLE_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_CGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_SGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_IGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_CGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_SGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_IGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.CGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.SGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.IGST_AMT, dbo.TRANSACTIONMASTER.TRANCSNAME, dbo.TRANSACTIONMASTER.TRANGSTNO AS CATEBGSTNO, dbo.TRANSACTIONMASTER.CATEAID, 
                         dbo.OPENSHEETMASTER.OSMNAME, MAX(dbo.OPENSHEETMASTER.OSMCNAME) AS OSMCNAME, SUM(dbo.OPENSHEETMASTER.OSMNOP) AS OSMNOP, SUM(dbo.OPENSHEETMASTER.OSMWGHT) AS OSMWGHT, 
                         dbo.TRANSACTIONMASTER.TRAN_COVID_DISC_AMT, '# 592,' AS COMPADDR1, 'ENNORE EXPRESS HIGH ROAD,' AS COMPADDR2, 'CHENNAI' AS COMPLOCTDESC, '600057' AS COMPPINCODE, '33' AS COMPSTATECODE, 
                         dbo.COMPANYMASTER.COMPPHN1, dbo.COMPANYMASTER.COMPMAIL, '12' AS COMPPOS, 'Nos' AS UNITCODE, 
                         dbo.TRANSACTIONMASTER.HANDL_TAXABLE_AMT + dbo.TRANSACTIONMASTER.HANDL_IGST_AMT + dbo.TRANSACTIONMASTER.HANDL_CGST_AMT + dbo.TRANSACTIONMASTER.HANDL_SGST_AMT AS TOTALITEMVAL, 
                         SUM(dbo.TRANSACTIONDETAIL.TRANDSAMT) AS STRG_AMT, 
                         SUM(dbo.TRANSACTIONDETAIL.TRANDHAMT + dbo.TRANSACTIONDETAIL.TRANDEAMT + dbo.TRANSACTIONDETAIL.TRANDFAMT + dbo.TRANSACTIONDETAIL.TRANDAAMT + dbo.TRANSACTIONMASTER.TRANAHAMT) 
                         AS HANDL_AMT, dbo.OPENSHEETMASTER.OSBBCHAADDR1 AS TRANIMPADDR1, dbo.OPENSHEETMASTER.OSBBCHAADDR2 AS TRANIMPADDR2, dbo.OPENSHEETMASTER.OSBBCHAADDR3 AS TRANIMPADDR3, 
                         dbo.OPENSHEETMASTER.OSBBCHAADDR4 AS TRANIMPADDR4, dbo.OPENSHEETMASTER.OSBBCHASTATEID, dbo.OPENSHEETMASTER.OSBBCHACATEAGSTNO, STATEMASTER_1.STATECODE, STATEMASTER_1.STATEDESC, 
                         dbo.CATEGORYMASTER.CATEPHN1, dbo.CATEGORYMASTER.CATEMAIL
FROM            dbo.STATEMASTER AS STATEMASTER_1 INNER JOIN
                         dbo.OPENSHEETDETAIL INNER JOIN
                         dbo.OPENSHEETMASTER ON dbo.OPENSHEETDETAIL.OSMID = dbo.OPENSHEETMASTER.OSMID ON STATEMASTER_1.STATEID = dbo.OPENSHEETMASTER.OSBBCHASTATEID INNER JOIN
                         dbo.CATEGORYMASTER ON STATEMASTER_1.STATEID = dbo.CATEGORYMASTER.STATEID AND dbo.OPENSHEETMASTER.OSBILLREFID = dbo.CATEGORYMASTER.CATEID RIGHT OUTER JOIN
                         dbo.TRANSACTIONMASTER INNER JOIN
                         dbo.TRANSACTIONDETAIL ON dbo.TRANSACTIONMASTER.TRANMID = dbo.TRANSACTIONDETAIL.TRANMID INNER JOIN
                         dbo.COMPANYACCOUNTINGDETAIL ON dbo.TRANSACTIONMASTER.COMPYID = dbo.COMPANYACCOUNTINGDETAIL.COMPYID INNER JOIN
                         dbo.COMPANYMASTER ON dbo.COMPANYACCOUNTINGDETAIL.COMPID = dbo.COMPANYMASTER.COMPID INNER JOIN
                         dbo.BILLENTRYDETAIL ON dbo.TRANSACTIONDETAIL.BILLEDID = dbo.BILLENTRYDETAIL.BILLEDID INNER JOIN
                         dbo.GATEINDETAIL ON dbo.BILLENTRYDETAIL.GIDID = dbo.GATEINDETAIL.GIDID INNER JOIN
                         dbo.CONTAINERSIZEMASTER ON dbo.GATEINDETAIL.CONTNRSID = dbo.CONTAINERSIZEMASTER.CONTNRSID INNER JOIN
                         dbo.BILLENTRYMASTER ON dbo.BILLENTRYDETAIL.BILLEMID = dbo.BILLENTRYMASTER.BILLEMID INNER JOIN
                         dbo.CONTAINERTYPEMASTER ON dbo.GATEINDETAIL.CONTNRTID = dbo.CONTAINERTYPEMASTER.CONTNRTID INNER JOIN
                         dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01 ON dbo.TRANSACTIONMASTER.TRANMID = dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01.TRANMID INNER JOIN
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01 ON dbo.TRANSACTIONMASTER.TRANMID = dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.TRANMID ON 
                         dbo.OPENSHEETDETAIL.BILLEDID = dbo.BILLENTRYDETAIL.BILLEDID LEFT OUTER JOIN
                         dbo.DELIVERYORDERDETAIL LEFT OUTER JOIN
                         dbo.DELIVERYORDERMASTER ON dbo.DELIVERYORDERDETAIL.DOMID = dbo.DELIVERYORDERMASTER.DOMID ON dbo.BILLENTRYDETAIL.BILLEDID = dbo.DELIVERYORDERDETAIL.BILLEDID LEFT OUTER JOIN
                         dbo.ROWMASTER RIGHT OUTER JOIN
                         dbo.SLOTMASTER ON dbo.ROWMASTER.ROWID = dbo.SLOTMASTER.ROWID ON dbo.GATEINDETAIL.SLOTID = dbo.SLOTMASTER.SLOTID LEFT OUTER JOIN
                         dbo.VW_TRANSACTION_DOSPRINT_ASSGN_01 ON dbo.TRANSACTIONMASTER.TRANMID = dbo.VW_TRANSACTION_DOSPRINT_ASSGN_01.TRANMID
WHERE        (ISNULL(dbo.DELIVERYORDERMASTER.DISPSTATUS, 0) = 0)
GROUP BY dbo.COMPANYMASTER.COMPNAME, dbo.TRANSACTIONMASTER.COMPYID, dbo.TRANSACTIONMASTER.TRANMID, dbo.TRANSACTIONMASTER.SDPTID, dbo.TRANSACTIONMASTER.REGSTRID, 
                         dbo.TRANSACTIONMASTER.TRANBTYPE, dbo.TRANSACTIONMASTER.TRANDATE, RIGHT(dbo.TRANSACTIONMASTER.TRANTIME, 8), dbo.TRANSACTIONMASTER.TRANNO, dbo.TRANSACTIONMASTER.TRANDNO, 
                         dbo.TRANSACTIONMASTER.TRANREFNAME, dbo.TRANSACTIONMASTER.TRANMODE, dbo.TRANSACTIONMASTER.TRANMODEDETL, dbo.TRANSACTIONMASTER.TRANREFNO, dbo.TRANSACTIONMASTER.TRANREFDATE, 
                         dbo.TRANSACTIONMASTER.TRANREFBNAME, dbo.TRANSACTIONMASTER.TRANREFAMT, dbo.TRANSACTIONMASTER.TRANGAMT, dbo.TRANSACTIONMASTER.TRANSAMT, dbo.TRANSACTIONMASTER.TRANHAMT, 
                         dbo.TRANSACTIONMASTER.TRANEAMT, dbo.TRANSACTIONMASTER.TRANFAMT, dbo.TRANSACTIONMASTER.TRANAAMT, dbo.TRANSACTIONMASTER.TRANNAMT, dbo.TRANSACTIONMASTER.TRANAMTWRDS, 
                         dbo.TRANSACTIONMASTER.TRANRMKS, dbo.TRANSACTIONMASTER.LMUSRID, dbo.TRANSACTIONMASTER.CUSRID, dbo.TRANSACTIONMASTER.LMUSRID, dbo.TRANSACTIONMASTER.DISPSTATUS, 
                         dbo.OPENSHEETMASTER.OSMLNAME, dbo.COMPANYMASTER.COMPPDESC1, dbo.COMPANYMASTER.COMPPDESC2, dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01.COL1, 
                         dbo.VW_TRANSACTION_CRY_PRINT_ASSGN_01.COL2, dbo.TRANSACTIONMASTER.TRANNARTN, dbo.TRANSACTIONMASTER.TRANPONO, dbo.GATEINDETAIL.CHANAME, dbo.GATEINDETAIL.CLNTNAME, 
                         dbo.GATEINDETAIL.SHPRNAME, dbo.GATEINDETAIL.GPPLCNAME, dbo.TRANSACTIONDETAIL.TRANDAHAMT, dbo.TRANSACTIONMASTER.TRANAHAMT, dbo.TRANSACTIONMASTER.TRANGSTNO, 
                         dbo.COMPANYMASTER.COMPGSTNO, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_HSNCODE, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_HSNCODE, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_CGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_SGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_IGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_CGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_SGST_EXPRN, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_IGST_EXPRN, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_TAXABLE_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_TAXABLE_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_CGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_SGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.STRG_IGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_CGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_SGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.HANDL_IGST_AMT, 
                         dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.CGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.SGST_AMT, dbo.VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01.IGST_AMT, 
                         dbo.TRANSACTIONMASTER.TRANCSNAME, dbo.TRANSACTIONMASTER.CATEAID, dbo.OPENSHEETMASTER.OSMNAME, dbo.TRANSACTIONMASTER.TRAN_COVID_DISC_AMT, dbo.COMPANYMASTER.COMPPHN1, 
                         dbo.COMPANYMASTER.COMPMAIL, 
                         dbo.TRANSACTIONMASTER.HANDL_TAXABLE_AMT + dbo.TRANSACTIONMASTER.HANDL_IGST_AMT + dbo.TRANSACTIONMASTER.HANDL_CGST_AMT + dbo.TRANSACTIONMASTER.HANDL_SGST_AMT, 
                         dbo.OPENSHEETMASTER.OSBBCHAADDR1, dbo.OPENSHEETMASTER.OSBBCHAADDR2, dbo.OPENSHEETMASTER.OSBBCHAADDR3, dbo.OPENSHEETMASTER.OSBBCHAADDR4, dbo.OPENSHEETMASTER.OSBBCHASTATEID, 
                         dbo.OPENSHEETMASTER.OSBBCHACATEAGSTNO, STATEMASTER_1.STATECODE, STATEMASTER_1.STATEDESC, dbo.CATEGORYMASTER.CATEPHN1, dbo.CATEGORYMASTER.CATEMAIL
HAVING        (dbo.TRANSACTIONMASTER.DISPSTATUS = 0)

GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[41] 4[20] 2[10] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -864
         Left = 0
      End
      Begin Tables = 
         Begin Table = "TRANSACTIONMASTER"
            Begin Extent = 
               Top = 7
               Left = 380
               Bottom = 115
               Right = 598
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "TRANSACTIONDETAIL"
            Begin Extent = 
               Top = 222
               Left = 38
               Bottom = 330
               Right = 263
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "COMPANYACCOUNTINGDETAIL"
            Begin Extent = 
               Top = 77
               Left = 769
               Bottom = 185
               Right = 936
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "COMPANYMASTER"
            Begin Extent = 
               Top = 249
               Left = 840
               Bottom = 357
               Right = 1046
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "BILLENTRYDETAIL"
            Begin Extent = 
               Top = 222
               Left = 301
               Bottom = 330
               Right = 468
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "GATEINDETAIL"
            Begin Extent = 
               Top = 438
               Left = 38
               Bottom = 546
               Right = 207
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CONTAINERSIZEMASTER"
            Begin Extent = 
               Top = 438
               Left = 245
               Bottom = 546
   ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Z_IMPORT_EINVOICE_DETAILS'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'            Right = 417
            End
            DisplayFlags = 280
            TopColumn = 2
         End
         Begin Table = "BILLENTRYMASTER"
            Begin Extent = 
               Top = 546
               Left = 38
               Bottom = 654
               Right = 205
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CONTAINERTYPEMASTER"
            Begin Extent = 
               Top = 546
               Left = 243
               Bottom = 654
               Right = 415
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "VW_TRANSACTION_CRY_PRINT_ASSGN_01"
            Begin Extent = 
               Top = 654
               Left = 38
               Bottom = 747
               Right = 205
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "VW_IMPORT_TRANSACTION_GST_PRINT_ASSGN_01"
            Begin Extent = 
               Top = 654
               Left = 243
               Bottom = 762
               Right = 448
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "STATEMASTER_1"
            Begin Extent = 
               Top = 726
               Left = 793
               Bottom = 834
               Right = 960
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "OPENSHEETDETAIL"
            Begin Extent = 
               Top = 762
               Left = 243
               Bottom = 870
               Right = 410
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "OPENSHEETMASTER"
            Begin Extent = 
               Top = 891
               Left = 926
               Bottom = 999
               Right = 1284
            End
            DisplayFlags = 280
            TopColumn = 39
         End
         Begin Table = "DELIVERYORDERDETAIL"
            Begin Extent = 
               Top = 870
               Left = 253
               Bottom = 978
               Right = 420
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "DELIVERYORDERMASTER"
            Begin Extent = 
               Top = 966
               Left = 38
               Bottom = 1074
               Right = 205
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "ROWMASTER"
            Begin Extent = 
               Top = 978
               Left = 243
               Bottom = 1086
               Right = 410
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "SLOTMASTER"
            Begin Extent = 
               Top = 1074
               Left = 38
               Bottom = 1182
               Right = 205
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "VW_TRANSACTION_DOSPRINT_ASSGN_01"
            Begin Extent = 
               Top = 1182
               Left = 38
               Bottom = 1275
               Right = 205
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "CATEGORYMASTER"
            Begin Extent = 
               Top = 870
               Left = 458
               Bottom = 1000
               Right = 666
            End
            DisplayFlags = 280
            TopColumn = 7
         End
      End
   End
   Begin SQLPane = 
   End
 ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Z_IMPORT_EINVOICE_DETAILS'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane3', @value=N'  Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 110
         Width = 284
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 12
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Z_IMPORT_EINVOICE_DETAILS'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=3 , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'VIEW',@level1name=N'Z_IMPORT_EINVOICE_DETAILS'
GO


