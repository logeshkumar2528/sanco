select *from  CATEGORYMASTER where CATENAME Like '%gmt%'

select *from CATEGORYMASTER

select *from GATEINDETAIL where CHANAME = 'GMT ALLOYS' 