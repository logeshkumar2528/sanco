USE [SCFS_ERP]
GO
/****** Object:  StoredProcedure [dbo].[pr_Search_Import_TruckIn]    Script Date: 04/10/2021 13:28:42 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Yamuna.J>
-- Create date: <24/07/2021>
-- Description:	<Export Gate In details>
-- =============================================
ALTER PROCEDURE [dbo].[pr_Search_Import_TruckIn]  /* CHANGE */
 @FilterTerm nvarchar(250) = NULL --parameter to search all columns by
        , @SortIndex INT = 1 -- a one based index to indicate which column to order by
        , @SortDirection CHAR(4) = 'ASC' --the direction to sort in, either ASC or DESC
        , @StartRowNum INT = 1 --the first row to return
        , @EndRowNum INT = 10 --the last row to return
        , @TotalRowsCount INT OUTPUT
        , @FilteredRowsCount INT OUTPUT
        , @PSDate Smalldatetime
        , @PEDate Smalldatetime
		,@PCOMPYID INT
		
 
AS BEGIN
    --Wrap filter term with % to search for values that contain @FilterTerm
    SET @FilterTerm = '%' + @FilterTerm + '%'
	declare @LSDate Smalldatetime
        , @LEDate Smalldatetime,@LCOMPYID INT
		set @LSDate=@PSDate
		set @LEDate=@PEDate
		set @LCOMPYID=@PCOMPYID

    DECLARE @TableMaster TABLE
    (
       GIDATE varchar(10)
      , GITIME varchar(10)
      , GINO int     
      , TRANSPORTER  VARCHAR(100)
	  , VHLNO VARCHAR(25)	  
	  , DISPSTATUS smallint
	  , GIDNO VARCHAR(100)
	  , DRVNAME VARCHAR(100)
	  , IGMNO VARCHAR(25)	 
	  , GIDID int 
      , RowNum INT
    )

    INSERT INTO @TableMaster(
	   GIDATE
	  , GITIME
      , GINO 
      , TRANSPORTER
	  , VHLNO
	  , DISPSTATUS
	  , GIDNO
	  , DRVNAME
	  , IGMNO
	  , GIDID
        , RowNum)
    SELECT  Convert(varchar(10), GIDATE,103) as GIDATE , CONVERT(VARCHAR(8),GITIME,108) as  GITIME  , GINO ,
	        GATEINDETAIL.TRNSPRTNAME as TRANSPORTER,VHLNO,GATEINDETAIL.DISPSTATUS,GIDNO,DRVNAME,IGMNO,  GIDID
            , Row_Number() OVER (
            ORDER BY
            
            /*VARCHAR, NVARCHAR, CHAR ORDER BY*/
            
            CASE @SortDirection
              WHEN 'ASC'  THEN
                CASE @SortIndex
           	      WHEN 2 then GINO			  	 
				    WHEN 3 then CATEGORYMASTER.CATENAME
			  	     WHEN 4 then VHLNO					    
						 WHEN 5 THEN GIDNO
						 	 WHEN 6 THEN DRVNAME
							 	 WHEN 7 THEN IGMNO
                END             
            END ASC,
            
            CASE @SortDirection
              WHEN 'DESC' THEN 
                CASE @SortIndex
           	      WHEN 2 then GINO			  	 
				    WHEN 3 then CATEGORYMASTER.CATENAME
			  	     WHEN 4 then VHLNO					    
						 WHEN 5 THEN GIDNO 
						  WHEN 6 THEN DRVNAME
							 	 WHEN 7 THEN IGMNO
                END
            END DESC,
            
            CASE @SortDirection
              WHEN 'ASC'  THEN
                CASE @SortIndex
                  WHEN 0 THEN GIDATE
                  WHEN 1 THEN GITIME
                END             
            END ASC,

            CASE @SortDirection
              WHEN 'DESC' THEN 
                CASE @SortIndex
                  WHEN 0 THEN GIDATE
				  when 1 then GITIME
                END
            END DESC
            
       
			                         

            ) AS RowNum
   FROM         dbo.GATEINDETAIL (nolock) Left JOIN CATEGORYMASTER  (nolock) On GATEINDETAIL.TRNSPRTID = CATEGORYMASTER.CATEID  /* CHANGE  TABLE NAME */
    WHERE (SDPTID=1)   and CONTNRSID = 0 And GATEINDETAIL.DISPSTATUS=0 --and (CONTNRID=1)
	        and (COMPYID=@LCOMPYID) and  (GIDATE BETWEEN @LSDate AND @LEDate) AND (@FilterTerm IS NULL 
              OR GIDATE LIKE @FilterTerm
              OR GITIME LIKE @FilterTerm
              OR GINO LIKE @FilterTerm
              OR  CONTNRNO  LIKE @FilterTerm
			  OR  CONTNRSID LIKE @FilterTerm
			    OR  CHANAME  LIKE @FilterTerm
				  OR  VHLNO LIKE @FilterTerm
			    OR  PRDTDESC  LIKE @FilterTerm
				OR GIDNO LIKE @FilterTerm
           )

     SELECT GIDATE , GITIME, GINO , isnull(TRANSPORTER,'') as  TRANSPORTER,VHLNO
	 ,case DISPSTATUS when 1 then 'C' when 0 then 'In book' end as  DISPSTATUS,GIDNO,DRVNAME,IGMNO 
	  , GIDID
    FROM    @TableMaster
    WHERE   RowNum BETWEEN @StartRowNum AND @EndRowNum
    ORDER BY GIDNO DESC

    SELECT @TotalRowsCount = COUNT(*)
   FROM        dbo.GATEINDETAIL  /* CHANGE  TABLE NAME */
  WHERE (SDPTID=1)  And DISPSTATUS=0  and CONTNRSID = 0 --and (CONTNRID=1)
	        and (COMPYID=@LCOMPYID) and  (GIDATE BETWEEN @LSDate AND @LEDate) 
    
    SELECT @FilteredRowsCount = COUNT(*)
    FROM   @TableMaster where DISPSTATUS = 0
        
END

