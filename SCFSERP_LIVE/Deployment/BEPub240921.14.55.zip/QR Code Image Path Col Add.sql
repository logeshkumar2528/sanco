select * from vehicleticketdetail

alter table vehicleticketdetail
add QRCDIMGPATH varchar(255) default ''