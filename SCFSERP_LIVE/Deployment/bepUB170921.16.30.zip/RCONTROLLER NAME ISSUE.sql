--select * from menurolemaster where roles = 'test'

--select * From AspNetRoles where Name like '%import%gate%'

update AspNetRoles set RControllerName='ImportRemoteGateIn' where RControllerName like 'RemoteGateIn'

update AspNetRoles set RControllerName='ImportGateIn' where RControllerName like 'ImportGateIn'

update AspNetRoles set RControllerName='ImportGateInBlock' where RControllerName like 'GateInBlock'
